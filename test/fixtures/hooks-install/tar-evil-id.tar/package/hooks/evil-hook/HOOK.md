---
name: evil-hook
description: evil-hook
metadata: {"openclaw":{"events":["command:new"]}}
---

# Hook